#pragma once
#include <cstdint>
#include <d3d12.h>
#include <wrl.h>

using Microsoft::WRL::ComPtr;

// ============================================================
// Magnetismic 用の簡易ベクトル/行列
// 既存エンジン側に Vector3 / Matrix4x4 があるなら置き換えてOK
// ============================================================
struct MagnetVec3 {
    float x;
    float y;
    float z;
};

struct MagnetVec4 {
    float x;
    float y;
    float z;
    float w;
};

struct MagnetMatrix4x4 {
    float m[4][4];
};

// ============================================================
// 頂点
// ============================================================
struct MagnetVertex {
    float position[3];
    float uv[2];
};

// ============================================================
// VS 用定数バッファ
// ============================================================
struct MagnetVSConstants {
    MagnetMatrix4x4 world;
    MagnetMatrix4x4 viewProj;
};

// ============================================================
// PS 用定数バッファ
// ============================================================
struct MagnetPSConstants {
    float time;
    float intensity;
    float alpha;
    float scale;

    float swirlA;
    float swirlB;
    float noiseScale;
    float stepScale;

    float colorA[4];  // 中心色
    float colorB[4];  // 外周色
    float params0[4]; // x=brightness y=distFade z=innerBoost w=unused
};

// ============================================================
// インスタンス用パラメータ
// ============================================================
struct MagnetismicInstance {
    MagnetVec3 position = {0.0f, 0.0f, 0.0f};
    float size = 3.0f;

    float time = 0.0f;
    float intensity = 1.0f;
    float alpha = 1.0f;

    float swirlA = 2.5f;
    float swirlB = 2.0f;
    float noiseScale = 3.5f;
    float stepScale = 1.0f;

    MagnetVec4 colorA = {1.00f, 0.25f, 0.65f, 1.0f}; // ピンク寄り
    MagnetVec4 colorB = {0.05f, 0.45f, 1.00f, 1.0f}; // 青寄り

    float brightness = 2.3f;
    float distFade = 0.35f;
    float innerBoost = 1.35f;
};

// ============================================================
// MagnetismicRenderer
// ============================================================
class MagnetismicRenderer {
  public:
    bool Initialize(ID3D12Device *device, DXGI_FORMAT rtvFormat,
                    DXGI_FORMAT dsvFormat, const wchar_t *vsPath,
                    const wchar_t *psPath);

    void BeginFrame(float deltaTime);
    void Draw(ID3D12GraphicsCommandList *commandList,
              const MagnetismicInstance &inst, const MagnetMatrix4x4 &viewProj,
              const MagnetVec3 &cameraRight, const MagnetVec3 &cameraUp);

  private:
    bool CreateRootSignature(ID3D12Device *device);
    bool CreatePipelineState(ID3D12Device *device, DXGI_FORMAT rtvFormat,
                             DXGI_FORMAT dsvFormat, const wchar_t *vsPath,
                             const wchar_t *psPath);

    bool CreateQuadResources(ID3D12Device *device);
    bool CreateConstantBuffers(ID3D12Device *device);

    void UpdateQuadVertices(const MagnetismicInstance &inst,
                            const MagnetVec3 &cameraRight,
                            const MagnetVec3 &cameraUp);

    static MagnetMatrix4x4 MakeIdentity();
    static MagnetMatrix4x4 MakeBillboardWorld(const MagnetVec3 &pos,
                                              const MagnetVec3 &right,
                                              const MagnetVec3 &up, float size);

  private:
    float elapsedTime_ = 0.0f;

    ComPtr<ID3D12RootSignature> rootSignature_;
    ComPtr<ID3D12PipelineState> pipelineState_;

    ComPtr<ID3D12Resource> vertexBuffer_;
    D3D12_VERTEX_BUFFER_VIEW vbView_{};

    ComPtr<ID3D12Resource> vsConstantBuffer_;
    ComPtr<ID3D12Resource> psConstantBuffer_;

    MagnetVertex *mappedVB_ = nullptr;
    MagnetVSConstants *mappedVS_ = nullptr;
    MagnetPSConstants *mappedPS_ = nullptr;
};