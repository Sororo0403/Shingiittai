#include "DirectXCommon.h"
#include "GameScene.h"
#include "Input.h"
#include "ModelManager.h"
#include "SceneContext.h"
#include "SceneManager.h"
#include "SoundManager.h"
#include "SpriteManager.h"
#include "SrvManager.h"
#include "TextureManager.h"
#include "WinApp.h"
#include <memory>
#include "WarpPostEffectRenderer.h"
#ifdef _DEBUG
#include "DebugDraw.h"
#endif // _DEBUG

#ifndef IMGUI_DISABLED
#include "ImguiManager.h"
#endif // IMGUI_DISABLED

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int nCmdShow) {
    // WinApp初期化
    WinApp winApp;
    winApp.Initialize(hInstance, nCmdShow, 1280, 720, L"3145_身技一体");

    // クライアント領域の幅と高さ
    int width = winApp.GetWidth();
    int height = winApp.GetHeight();

    // DirectX
    DirectXCommon dxCommon;
    dxCommon.Initialize(winApp.GetHwnd(), width, height);

    // SrvManager
    SrvManager srvManager;
    srvManager.Initialize(&dxCommon, 512);
    dxCommon.RegisterSceneColorSRV(&srvManager);

    WarpPostEffectRenderer warpPostEffectRenderer;
    warpPostEffectRenderer.Initialize(&dxCommon, &srvManager);
    WarpPostEffectParamGPU warpPostParam{};

    // Input
    Input input;
    input.Initialize(hInstance, winApp.GetHwnd());

    // SoundManager
    SoundManager soundManager;
    soundManager.Initialize();

    // TextureManager
    TextureManager textureManager;
    textureManager.Initialize(&dxCommon, &srvManager);

    // ModelManager
    ModelManager modelManager;
    modelManager.Initialize(&dxCommon, &srvManager, &textureManager);

    // SpriteManager
    SpriteManager spriteManager;
    spriteManager.Initialize(&dxCommon, &textureManager, &srvManager, width,
                             height);

    dxCommon.BeginUpload();

#ifdef _DEBUG
    // DebugDraw
    DebugDraw debugDraw;
    uint32_t boxModelId = modelManager.Load(L"resources/model/debug/box.glb");
#endif // _DEBUG

    dxCommon.EndUpload();

    textureManager.ReleaseUploadBuffers();

#ifdef _DEBUG
    debugDraw.Initialize(boxModelId);
#endif // _DEBUG

#ifndef IMGUI_DISABLED
    // ImguiManager
    ImguiManager imguiManager;
    imguiManager.Initialize(&winApp, &dxCommon, &srvManager);
#endif // IMGUI_DISABLED

    SceneContext sceneCtx{};
    sceneCtx.input = &input;
    sceneCtx.winApp = &winApp;
    sceneCtx.sound = &soundManager;
    sceneCtx.model = &modelManager;
    sceneCtx.sprite = &spriteManager;
    sceneCtx.texture = &textureManager;
    sceneCtx.dxCommon = &dxCommon;
    sceneCtx.warpPostEffectParam = &warpPostParam;

    sceneCtx.deltaTime = 0.0f;

#ifdef _DEBUG
    sceneCtx.debugDraw = &debugDraw;
#endif // _DEBUG

#ifndef IMGUI_DISABLED
    sceneCtx.imgui = &imguiManager;
#endif // IMGUI_DISABLED

    // SceneManager
    SceneManager sceneManager;
    sceneManager.Initialize(sceneCtx);
    sceneManager.ChangeScene(std::make_unique<GameScene>());

    // 高精細タイマの周波数を取得
    LARGE_INTEGER freq;
    QueryPerformanceFrequency(&freq);

    LARGE_INTEGER prevTime;
    QueryPerformanceCounter(&prevTime);

    // メインループ
    while (winApp.ProcessMessage()) {
        // deltaTime計算
        LARGE_INTEGER currentTime;
        QueryPerformanceCounter(&currentTime);

        float deltaTime =
            static_cast<float>(currentTime.QuadPart - prevTime.QuadPart) /
            static_cast<float>(freq.QuadPart);

        prevTime = currentTime;

        sceneCtx.deltaTime = deltaTime;

        // 入力更新
        input.Update(deltaTime);

        // Scene 更新
        sceneManager.Update();

               // 描画
        dxCommon.BeginFrame();

#ifndef IMGUI_DISABLED
        ID3D12GraphicsCommandList *cmdList = dxCommon.GetCommandList();
        imguiManager.Begin(cmdList);
#endif // IMGUI_DISABLED

        dxCommon.BeginScenePass();
        sceneManager.Draw();
        dxCommon.EndScenePass();

        dxCommon.BeginBackBufferPass();

        warpPostEffectRenderer.Draw(warpPostParam,
                                    dxCommon.GetSceneSrvGpuHandle(&srvManager));

#ifndef IMGUI_DISABLED
        imguiManager.End(cmdList);
#endif // IMGUI_DISABLED

        dxCommon.EndFrame();
    }

    return 0;
}
