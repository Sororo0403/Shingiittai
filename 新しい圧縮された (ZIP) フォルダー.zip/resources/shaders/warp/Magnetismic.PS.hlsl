cbuffer PSConstants : register(b1)
{
    float gTime;
    float gIntensity;
    float gAlpha;
    float gScale;

    float gSwirlA;
    float gSwirlB;
    float gNoiseScale;
    float gStepScale;

    float4 gColorA;
    float4 gColorB;
    float4 gParams0; // x=brightness y=distFade z=innerBoost w=unused
};

struct PSInput
{
    float4 pos : SV_POSITION;
    float2 uv : TEXCOORD0;
};

// ============================================================
// 回転
// ============================================================
float2 Rot(float2 p, float a)
{
    float c = cos(a);
    float s = sin(a);
    return float2(c * p.x - s * p.y, s * p.x + c * p.y);
}

// ============================================================
// hash / noise / fbm
// 元の iChannel0 依存をやめて、手続きノイズで置換
// ============================================================
float Hash11(float n)
{
    return frac(sin(n) * 43758.5453123);
}

float Hash31(float3 p)
{
    return frac(sin(dot(p, float3(12.9898, 78.233, 37.719))) * 43758.5453123);
}

float Noise3D(float3 p)
{
    float3 i = floor(p);
    float3 f = frac(p);

    f = f * f * (3.0 - 2.0 * f);

    float n000 = Hash31(i + float3(0, 0, 0));
    float n100 = Hash31(i + float3(1, 0, 0));
    float n010 = Hash31(i + float3(0, 1, 0));
    float n110 = Hash31(i + float3(1, 1, 0));
    float n001 = Hash31(i + float3(0, 0, 1));
    float n101 = Hash31(i + float3(1, 0, 1));
    float n011 = Hash31(i + float3(0, 1, 1));
    float n111 = Hash31(i + float3(1, 1, 1));

    float nx00 = lerp(n000, n100, f.x);
    float nx10 = lerp(n010, n110, f.x);
    float nx01 = lerp(n001, n101, f.x);
    float nx11 = lerp(n011, n111, f.x);

    float nxy0 = lerp(nx00, nx10, f.y);
    float nxy1 = lerp(nx01, nx11, f.y);

    return lerp(nxy0, nxy1, f.z);
}

float FBM(float3 p)
{
    float v = 0.0;
    float a = 0.5;

    [unroll]
    for (int i = 0; i < 4; ++i)
    {
        float n = Noise3D(p - gTime * 0.6);
        v += (sin(n * 4.4) - 0.45) * a;
        p *= 3.5;
        a *= 0.47;
    }

    return v;
}

// ============================================================
// 元 Magnetismic の map を HLSL 化
// ============================================================
float4 MapMagnet(float3 p)
{
    float dtp = dot(p, p);

    // 中心吸い込み気味の歪み
    p = 0.5 * p / (dtp + 0.2);

    // 2軸に対してねじる
    p.xz = Rot(p.xz, p.y * gSwirlA);
    p.xy = Rot(p.xy, p.z * gSwirlB);

    float dtp2 = dot(p, p);

    // 元コードの "mo.y + .6" 相当を固定気味にして安定化
    float mouseLike = 1.6;
    p = mouseLike * 3.0 * p / max(dtp2 - 5.0, -4.8);

    float n = FBM(p * gNoiseScale);
    float r = saturate(n * 1.5 - dtp * (gParams0.y - sin(gTime * 0.3) * 0.15));

    // 色は元コードを青ピンク方向へ寄せる
    float3 col = lerp(gColorB.rgb, gColorA.rgb, r);

    float grd = saturate((dtp + 0.7) * 0.4);

    // 外周を青く
    col = lerp(col, gColorB.rgb, grd * 0.65);

    float3 lv = lerp(p, float3(0.3, 0.3, 0.3), 2.0);
    float grd2 = clamp((r - FBM(p + lv * 0.05)) * 2.0, 0.01, 1.5);

    col *= lerp(float3(0.5, 0.4, 0.6), float3(4.0, 0.0, 0.4), saturate(grd2 * 0.7));

    float alpha = lerp(0.87, 0.94, saturate(dtp * 2.0 - 1.0));
    alpha *= saturate(r * 1.2 + 0.15);

    return float4(col, alpha);
}

// ============================================================
// ビルボードの平面上で疑似レイマーチ
// 元の Shadertoy は本当のカメラレイだったが、
// ここでは局所空間で近い見え方を作る
// ============================================================
float4 VolumeMarch(float2 uv)
{
    float2 p = uv * 2.0 - 1.0;
    p *= 1.15;

    float3 ro = float3(0.0, 0.0, -4.0);
    float3 rd = normalize(float3(p.x * 0.85, p.y * 0.85, 1.8));

    float4 accum = float4(0, 0, 0, 0);

    float t = 2.5 + 0.03 * Hash11((uv.x + uv.y) * 1234.567);
    const int STEPS = 96;

    [loop]
    for (int i = 0; i < STEPS; ++i)
    {
        if (accum.a > 0.99 || t > 6.0)
        {
            break;
        }

        float3 pos = ro + rd * t;
        float4 col = MapMagnet(pos);

        float den = col.a;
        col.a *= 0.018 * gStepScale;
        col.rgb *= col.a * (1.7 * gParams0.x);

        accum += col * (1.0 - accum.a);

        float baseStep = 0.025 * gStepScale;
        t += baseStep - den * (baseStep - baseStep * 0.015);
    }

    return saturate(accum);
}

float RadialMask(float2 uv)
{
    float2 d = uv * 2.0 - 1.0;
    float r = length(d);

    // 外周でなめらかに消す
    float m = 1.0 - smoothstep(0.65, 1.08, r);
    return m;
}

float4 main(PSInput input) : SV_TARGET
{
    float2 uv = input.uv;

    float4 col = VolumeMarch(uv);

    // 中央に芯を少し足して、画像のピンク核に寄せる
    float2 c = uv * 2.0 - 1.0;
    float core = exp(-dot(c, c) * 7.0) * gParams0.z;
    col.rgb += gColorA.rgb * core * 0.65;

    // 少しブルーム前提の強さを持たせる
    col.rgb *= gIntensity;

    // 外周マスク
    float mask = RadialMask(uv);
    col.rgb *= mask;
    col.a *= mask * gAlpha;

    // ゲーム内で使いやすいように黒背景を透過扱いに近づける
    return float4(col.rgb, col.a);
}